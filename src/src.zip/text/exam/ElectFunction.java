package text.exam;

interface ElectFunction {
	void start();

	void stop();

	void display();

}
