package board;

public class QABoardImpl implements BoardIneterface {

	@Override
	public boolean insert(Board board) {
		System.out.println("QABoardImpl�� insert�Դϴ�.");
		return false;
	}

	@Override
	public Board selectByNo(int no) {
		System.out.println("QABoardImpl�� selectByNo�Դϴ�.");
		return null;
	}

}
