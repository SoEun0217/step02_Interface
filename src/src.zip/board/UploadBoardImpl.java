package board;

public class UploadBoardImpl implements BoardIneterface {

	@Override
	public boolean insert(Board board) {
		System.out.println("UploadBoardImpl�� insert�Դϴ�.");
		return false;
	}

	@Override
	public Board selectByNo(int no) {
		System.out.println("UploadBoardImpl�� insert�Դϴ�.");
		return null;
	}

}
